import React, { Component } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Container, Row, Col, Card, Button } from "react-bootstrap";
import { BUY_PRODUCT } from "../redux/actions";

function AllRooms() {
  const AllData = useSelector(state => state.Room);
  console.log(AllData);
  const dispatch = useDispatch();
  const AddToCart = e => {
    const thisSlug = e.target.id;
    dispatch(BUY_PRODUCT(thisSlug));
  };
  const AllRoomsTitles = AllData.map((item, index) => {
    return (
      <Col sm={3}>
        <Card className="mb-3">
          <Card.Img src={item.fields.images[0].fields.file.url} />
          <Card.Body>
            <Card.Title>{item.fields.name}</Card.Title>
            <div className="d-flex justify-content-between">
              <Card.Text>Price: ${item.fields.price}</Card.Text>
              <Button
                variant="primary"
                size="sm"
                disabled={item.fields.buyDisabled ? false : true}
                id={item.fields.name}
                onClick={event => AddToCart(event)}
              >
                BUY
              </Button>
            </div>
          </Card.Body>
        </Card>
      </Col>
    );
  });
  return <>{AllRoomsTitles}</>;
}

class ShowAllRooms extends Component {
  render() {
    return (
      <Container>
        <Row>
          <AllRooms />
        </Row>
      </Container>
    );
  }
}

export default ShowAllRooms;
