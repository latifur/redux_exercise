import React, { Component } from "react";
import { useSelector, useDispatch } from "react-redux";
import { Container, Row, Col, Button, Card } from "react-bootstrap";
import { BUY_PRODUCT } from "../redux/actions";

function AllPhones() {
  const AllData = useSelector(state => state.Phone);
  console.log(AllData);
  const dispatch = useDispatch();
  const AddToCart = e => {
    const thisSlug = e.target.id;
    dispatch(BUY_PRODUCT(thisSlug));
  };
  const AllPhoneTitles = AllData.map((item, index) => {
    return (
      <Col sm={3} key={index}>
        <Card key={index} className="mb-3">
          <Card.Img variant="top" src={item.img} />
          <Card.Body>
            <Card.Title>{item.title}</Card.Title>
            <div className="d-flex justify-content-between">
              <Card.Text>Price: ${item.price}</Card.Text>
              <Button
                variant="primary"
                size="sm"
                disabled={item.buyDisabled ? false : true}
                id={item.title}
                onClick={event => AddToCart(event)}
              >
                BUY
              </Button>
            </div>
          </Card.Body>
        </Card>
      </Col>
    );
  });
  return <>{AllPhoneTitles}</>;
}

class ShowAllPhone extends Component {
  render() {
    return (
      <Container>
        <Row>
          <AllPhones />
        </Row>
      </Container>
    );
  }
}

export default ShowAllPhone;
