import React from "react";
import { NavDropdown } from "react-bootstrap";
import { useSelector, useDispatch } from "react-redux";
import { BUY_PRODUCT } from "../../redux/actions";

function ProductCart() {
  const ShopCart = useSelector(state => state.Cart);

  return (
    <>
      {ShopCart.cartItem.map((item, index) => {
        return (
          <NavDropdown.Item href="#" key={index}>
            {item}
          </NavDropdown.Item>
        );
      })}
    </>
  );
}

export default ProductCart;
