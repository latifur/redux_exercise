export const BUY_PRODUCT = slug => {
  return {
    type: "BUY_PRODUCT",
    payload: {
      itemSlug: slug
    }
  };
};
