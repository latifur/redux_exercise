import { storeProducts } from "../../data/phones/data";

import RoomData from "../../data/rooms/data";

export const AllData = storeProducts;
export const AllRoomData = RoomData;
