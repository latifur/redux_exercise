const initialState = {
  itemIntoCart: 0,
  cartItem: []
};

export const CartReducer = (state = initialState, action) => {
  switch (action.type) {
    case "BUY_PRODUCT": {
      const NewState = {
        itemIntoCart: state.itemIntoCart + 1,
        cartItem: [...state.cartItem, action.payload.itemSlug]
      };
      state = NewState;
      console.log(state);
      return state;
    }
    default: {
      return state;
    }
  }
};
