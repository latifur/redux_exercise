import React from "react";
import { Provider } from "react-redux";
import { Switch, Route } from "react-router-dom";
import { store } from "./redux/store";
import ShowAllPhones from "./component/showAllPhone";
import ShowAllRooms from "./component/showAllRooms";
import AppNavbar from "./component/navbar/navbar";
import "bootstrap/dist/css/bootstrap.min.css";
import "./App.css";

function App() {
  return (
    <Provider store={store}>
      <AppNavbar />

      <Switch>
        <Route path="/phones" exact component={ShowAllPhones} />
        <Route path="/rooms" exact component={ShowAllRooms} />
      </Switch>
    </Provider>
  );
}

export default App;
